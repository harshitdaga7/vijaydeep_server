const data = {

    secret:"Zw3y6B8DaGdJfMjQmSqVsXu2x4z6C9EbGeKgNkRnTqWtYv2y5A",
    duration:3600
    
}


module.exports = data;