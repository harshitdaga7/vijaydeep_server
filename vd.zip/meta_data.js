const data = {

    home : "Vijaydeep Agencies is a distinguished importer, exporter and trader offering an enormous consignment of Diagnostics, Surgical and Pharmacutical equipment.",
    about : "Vijaydeep Agencies is a distinguished importer, exporter and trader offering an enormous consignment of Diagnostics, Surgical and Pharmacutical equipment. Know more about us",
    news : "Vijaydeep Agencies is a distinguished importer, exporter and trader offering an enormous consignment of Diagnostics, Surgical and Pharmacutical equipment. Be upto-date with news from our industry. ",
    team : "know more about the team that make up vijaydeep agency",
    products : "Vijaydeep Agencies is a distinguished importer, exporter and trader offering an enormous consignment of Diagnostics, Surgical and Pharmacutical equipment. Check our about our products.",
    contact : "how to contact and reach us",
    disclaimer : "this consists sites disclaimer",
    console : "console",
    console_news : "console_news",
    console_about : "console_about",
    console_products : "console_products",
    console_team : "console_team",
    console_users:"console_users",

}

module.exports = data;